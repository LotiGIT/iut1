public class TestEmission {
    public static void main(String[] args) {
        Chanson c1 = new Chanson("La lettre", "J'ai reçu une lettre\n" + //
                "Il y a un mois peut-être\n" + //
                "Arrivée par erreur\n" + //
                "Maladresse de facteur\n" + //
                "Aspergée de parfum\n" + //
                "Rouge à lèvres carmin\n" + //
                "J'aurais dû cette lettre\n" + //
                "Ne pas l'ouvrir peut-être\n" + //
                "Mais moi je suis un homme\n" + //
                "Qui aime bien ce genre de jeu\n" + //
                "Veux bien qu'elle me nomme\n" + //
                "Alphonse ou Fred c'est comme elle veut\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "C'est comme elle veut\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Des jolies marguerites\n" + //
                "Sur le haut de ses \"i\"\n" + //
                "Des courbes manuscrites\n" + //
                "Comme dans les abbayes\n" + //
                "Quelques fautes d'orthographe\n" + //
                "Une légère dyslexie\n" + //
                "Et en guise de paraphe\n" + //
                "\"Ta petite blonde sexy\"\n" + //
                "Et moi je suis un homme\n" + //
                "Qui aime bien ce genre de jeu\n" + //
                "N'aime pas les nonnes\n" + //
                "Et j'en suis tombé amoureux\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Amoureux (pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Elle écrit que dimanche\n" + //
                "Elle sera sur la falaise\n" + //
                "Où je l'ai prise par les hanches\n" + //
                "Et que dans l'hypothèse\n" + //
                "Où j'n'aurais pas le tact\n" + //
                "D'assumer mes ébats\n" + //
                "Elle choisira l'impact\n" + //
                "Trente mètres plus bas\n" + //
                "Et moi je suis un homme\n" + //
                "Qui aime bien ce genre d'enjeu\n" + //
                "N'veux pas qu'elle s'assomme\n" + //
                "Car j'en suis tombé amoureux\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Amoureux (pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Et grâce au cachet d'la poste\n" + //
                "D'une ville sur la Manche\n" + //
                "J'étais à l'avant-poste\n" + //
                "Au matin du dimanche\n" + //
                "L'endroit était désert\n" + //
                "Il faudra être patient\n" + //
                "Des blondes suicidaires\n" + //
                "Il n'y en a pas cent\n" + //
                "Et moi je suis un homme\n" + //
                "Qui aime bien ce genre d'enjeu\n" + //
                "Veux battre Newton\n" + //
                "Car j'en suis tombé amoureux\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Amoureux (pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Elle surplombait la Manche\n" + //
                "Quand je l'ai reconnue\n" + //
                "J'ai saisi par la manche\n" + //
                "Ma petite ingénue\n" + //
                "Qui ne l'était pas tant\n" + //
                "Au regard du profil\n" + //
                "Qu'un petit habitant\n" + //
                "Lui faisait sous le nombril\n" + //
                "Et moi je suis un homme\n" + //
                "Qui aime bien ce genre d'enjeu\n" + //
                "Veux bien qu'il me nomme\n" + //
                "\"Papa\" s'il le veut\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "S'il le veut! (Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Et moi je suis un homme\n" + //
                "Qui aime bien ce genre d'enjeu\n" + //
                "Veux bien qu'il me nomme\n" + //
                "\"Papa\" s'il le veut\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "S'il le veut! (Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Payapapa yapapa\n" + //
                "Payapapa papapa\n" + //
                "Yapapa yapapa\n" + //
                "Pa-ya-pa-pa, pa-pa-ya-pa\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "Pa-ya-pa-pa, pa-pa-ya-pa\n" + //
                "(Pa-ya-pa-pa, pa-pa-ya-pa)\n" + //
                "", 3, 17);
        Chanson c2 = new Chanson("Repenti", "Des spaghettis d'la sauce tomate\n" + //
                "Dans la banlieue nord de Dijon\n" + //
                "J'ai choisi la voie diplomate\n" + //
                "Qui m'a évité la prison\n" + //
                "Ça fait 20 ans que je me cache\n" + //
                "Et je pensais vivre bien moins\n" + //
                "Le FBI remplit sa tâche\n" + //
                "La protection d'un témoin\n" + //
                "Repenti\n" + //
                "J'ai trahi\n" + //
                "J'aurais bien pu casser des pierres\n" + //
                "Au pénitencier du Texas\n" + //
                "Mais je me finis à la bière\n" + //
                "Dans un PMU bien moins classe\n" + //
                "Tous les soirs on remplit mon verre\n" + //
                "Et on rigole on me salit\n" + //
                "Quand je raconte les tours de verre\n" + //
                "Ma vie à Little Italy\n" + //
                "Repenti\n" + //
                "J'ai trahi\n" + //
                "Mafioso jusqu'au bout des ongles\n" + //
                "J'suis dev'nu le poch'tron du coin\n" + //
                "Quand les hommes de main de mon oncle\n" + //
                "Recherchent Tony-Les-Deux-Poings\n" + //
                "Dans les premiers mois de ma planque\n" + //
                "J'ai cru qu'ma vie serait la même\n" + //
                "En recréant ce qui me manque\n" + //
                "De ma Sicile américaine\n" + //
                "J'ai aidé quelques connaissances\n" + //
                "Dans leurs querelles de voisinage\n" + //
                "Deux trois corps imbibés d'essence\n" + //
                "Quelques accidents de ménage\n" + //
                "Repenti\n" + //
                "J'ai trahi\n" + //
                "Mafioso jusqu'au bout des ongles\n" + //
                "J'suis dev'nu le poch'tron du coin\n" + //
                "Quand les hommes de main de mon oncle\n" + //
                "Recherchent Tony-Les-Deux-Poings\n" + //
                "Mes p'tits voisins des frères et soeurs\n" + //
                "Me montraient leur carnet de notes\n" + //
                "Je rencontrais leurs professeurs\n" + //
                "Et prélevais quelques quenottes\n" + //
                "Mais aujourd'hui je suis trop vieux\n" + //
                "Je m'occupe de mes hortensias\n" + //
                "C'est étrange comme ils poussent mieux\n" + //
                "Qu'ai-je bien pu donc enterrer là\n" + //
                "Repenti\n" + //
                "J'ai trahi\n" + //
                "Dans les fourrés quelque chose bouge\n" + //
                "J'aperçois l'ombre d'un sniper\n" + //
                "Sur ma poitrine une lumière rouge\n" + //
                "Je t'attendais je n'ai pas peur\n" + //
                "Qu'on m'allonge sur mon lit\n" + //
                "Sur mon coeur une fleur d'hortensia\n" + //
                "Je vais revoir le Stromboli\n" + //
                "Je vais oublier la Mafia\n" + //
                "Repenti\n" + //
                "J'ai trahi\n" + //
                "Repenti\n" + //
                "J'ai trahi", 4, 07);


    }

    EmissionMusicale em1 = new EmissionMusicale("Première emission", 15);
    EmissionMusicaleCommentee emc1 = new EmissionMusicaleCommentee("Nagui", "Première emission commentée", 10);
}
