module TD4 {
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	opens package2 to javafx.graphics, javafx.fxml; 	
}