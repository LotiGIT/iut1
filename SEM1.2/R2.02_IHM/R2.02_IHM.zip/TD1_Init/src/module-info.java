/**
 * 
 */
/**
 * @author ejanot
 *
 */
module TD1_Init {
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	opens newPackage to javafx.graphics, javafx.fxml; 	
}