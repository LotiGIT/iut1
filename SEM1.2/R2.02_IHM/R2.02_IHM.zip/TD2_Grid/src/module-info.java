module TD2_Grid {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
